package com.torrefactora;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GestionTareasBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
